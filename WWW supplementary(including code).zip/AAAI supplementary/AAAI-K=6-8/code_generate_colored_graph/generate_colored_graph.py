import itertools
from collections import deque
import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
import math
from math import ceil, factorial

"""set path length k"""
k = 4  # Modify this value to 7 or 8 for other k-values

# Color constants
RED = 'red'
BLACK = 'black'
GRAY = 'gray'

# Color mapping (for plotting)
COLOR_MAP = {
    RED: 'red',
    BLACK: 'black',
    GRAY: 'gray'
}

# Calculate factorial product
def compute_factorial_product(adj, colors):
    n = len(adj)
    red_vertices = [i for i in range(n) if colors[i] == 'red']
    black_vertices = [i for i in range(n) if colors[i] == 'black']
    gray_vertices = [i for i in range(n) if colors[i] == 'gray']
    
    product = 1
    
     # Factorial part for gray vertices
    for v in gray_vertices:
        deg = sum(adj[v])
        half_deg = deg // 2
        product *= factorial(half_deg - 1)
    
    # Case with black vertices
    if black_vertices:
        red_deg = sum(adj[red_vertices[0]])
        black_deg = sum(adj[black_vertices[0]])
        
        red_half = ceil(red_deg / 2)
        black_half = ceil(black_deg / 2)
        
        product *= factorial(red_half - 1)
        product *= factorial(black_half - 1)
    
    # Case without black vertices
    else:
        red_deg = sum(adj[red_vertices[0]])
        red_half = ceil(red_deg / 2)
        product *= factorial(red_half)
    
    return product

def generate_eulerian_paths(adj, start, end):
    """Generate all Eulerian paths from start to end"""
    n = len(adj)
    paths = []

    def backtrack(path, edge_counts):
        current = path[-1]
        all_used = True
        for i in range(n):
            for j in range(n):
                if i != j and edge_counts[i][j] > 0:
                    all_used = False
                    break
            if not all_used:
                break

        if all_used:
            if current == end:
                paths.append(list(path))
            return

        for neighbor in range(n):
            if neighbor != current and edge_counts[current][neighbor] > 0:
                new_edge_counts = [row[:] for row in edge_counts]
                new_edge_counts[current][neighbor] -= 1
                new_edge_counts[neighbor][current] -= 1
                new_path = path + [neighbor]
                backtrack(new_path, new_edge_counts)

    initial_edge_counts = [row[:] for row in adj]
    backtrack([start], initial_edge_counts)
    return paths


def get_color_preserving_automorphisms(adj, colors):
    """Return all color-preserving automorphic permutations (in list form)"""
    n = len(adj)
    color_groups = {}
    for i in range(n):
        color = colors[i]
        color_groups.setdefault(color, []).append(i)
    color_order = sorted(color_groups.keys())
    groups_list = [color_groups[color] for color in color_order]
    perms_list = [list(itertools.permutations(g)) for g in groups_list]
    automorphisms = []

    for perm_tuple in itertools.product(*perms_list):
        # Initialize as identity mapping
        perm = list(range(n))

        # Populate mapping by group
        for idx, color in enumerate(color_order):
            group = groups_list[idx]
            group_perm = perm_tuple[idx]
            if len(group) != len(group_perm):
                raise ValueError(f"Group {group} and permutation {group_perm} have inconsistent lengths")
            for original, mapped in zip(group, group_perm):
                perm[original] = mapped

        # Verify if it's an automorphism
        is_automorphism = True
        for i in range(n):
            for j in range(n):
                if adj[i][j] != adj[perm[i]][perm[j]]:
                    is_automorphism = False
                    break
            if not is_automorphism:
                break
        if is_automorphism:
            automorphisms.append(perm)

    return automorphisms

def count_structural_euler_paths(adj, colors):
    """Count the number of structural Eulerian paths or circuits in the graph"""
    n = len(adj)
    red_vertices = [i for i in range(n) if colors[i] == RED]
    black_vertices = [i for i in range(n) if colors[i] == BLACK]

    if black_vertices:
        start_vertices = red_vertices
        end_vertices = black_vertices
        is_circuit = False
    else:
        start_vertices = red_vertices
        end_vertices = red_vertices
        is_circuit = True

    automorphisms = get_color_preserving_automorphisms(adj, colors)
    unique_structures = set()

    for start in start_vertices:
        for end in end_vertices:
            paths = generate_eulerian_paths(adj, start, end)
            for path in paths:
                min_form = None
                for perm in automorphisms:
                    transformed_path = [perm[v] for v in path]
                    path_str = ','.join(map(str, transformed_path))
                    if min_form is None or path_str < min_form:
                        min_form = path_str
                if min_form is not None:
                    unique_structures.add(min_form)

    return len(unique_structures)

def is_connected(adj, n):
    """Check if the graph represented by adjacency matrix is connected (no self-loops)"""
    if n == 0:
        return False
    visited = [False] * n
    queue = deque([0])
    visited[0] = True
    count = 1
    while queue:
        i = queue.popleft()
        for j in range(n):
            if adj[i][j] > 0 and not visited[j]:
                visited[j] = True
                queue.append(j)
                count += 1
    return count == n

def canonical_representation(adj, deg):
    """"Generate canonical representation of the graph (for isomorphism comparison, no self-loops)"""
    n = len(adj)
    groups_dict = {}
    for i in range(n):
        d = deg[i]
        groups_dict.setdefault(d, []).append(i)
    sorted_degrees = sorted(groups_dict.keys())
    groups_list = [groups_dict[d] for d in sorted_degrees]
    
    min_tuple = None
    perms_list = [list(itertools.permutations(g)) for g in groups_list]
    
    for perms in itertools.product(*perms_list):
        new_order = []
        for perm in perms:
            new_order.extend(perm)
        
        tuple_rep = []
        for i in range(n):
            for j in range(i + 1, n):
                u, v = new_order[i], new_order[j]
                tuple_rep.append(adj[u][v])
        rep_tuple = tuple(tuple_rep)
        
        if min_tuple is None or rep_tuple < min_tuple:
            min_tuple = rep_tuple
    
    return min_tuple

def canonical_representation_with_colors(adj, colors):
    """Generate canonical representation of the graph (considering color correspondence)"""
    n = len(adj)
    
    # Group vertices by color
    color_groups = {}
    for i in range(n):
        color = colors[i]
        color_groups.setdefault(color, []).append(i)
    
    # Sort by color (ensure color correspondence)
    sorted_colors = sorted(color_groups.keys())
    groups_list = [color_groups[color] for color in sorted_colors]
    
    # Try all possible permutations (within color groups)
    perms_list = [list(itertools.permutations(group)) for group in groups_list]
    
    min_tuple = None
    for perms in itertools.product(*perms_list):
        # Construct new vertex order
        new_order = []
        for perm in perms:
            new_order.extend(perm)
        
        # Build canonical representation (flattened adjacency matrix)
        tuple_rep = []
        for i in range(n):
            for j in range(i + 1, n):
                u, v = new_order[i], new_order[j]
                tuple_rep.append(adj[u][v])
        rep_tuple = tuple(tuple_rep)
        
        if min_tuple is None or rep_tuple < min_tuple:
            min_tuple = rep_tuple
    
    return min_tuple
def generate_color_configurations(adj, deg):
    """Generate all possible color configurations for the graph (start, end, gray)"""
    n = len(adj)
    odd_vertices = [i for i in range(n) if deg[i] % 2 != 0]
    configurations = []

    if len(odd_vertices) == 0:
        # Eulerian circuit: all vertices have even degree, start and end are the same vertex (red)
        for start in range(n):
            colors = [GRAY] * n
            colors[start] = RED
            configurations.append((adj, colors))
    elif len(odd_vertices) == 2:
        # Eulerian path: two vertices with odd degree, swap start and end
        v1, v2 = odd_vertices
        # Configuration 1: v1 is start (red), v2 is end (black)
        colors1 = [GRAY] * n
        colors1[v1] = RED
        colors1[v2] = BLACK
        configurations.append((adj, colors1))
        # Configuration 2: v2 is start (red), v1 is end (black)
        colors2 = [GRAY] * n
        colors2[v2] = RED
        colors2[v1] = BLACK
        configurations.append((adj, colors2))
    else:
        # Invalid graph (filtered by Eulerian conditions)
        pass

    return configurations

def draw_graph_with_colors(adj, ax, title, colors):
    """Draw the graph using networkx, considering vertex colors"""
    n = len(adj)
    G = nx.MultiGraph()
    
    # Add vertices and edges
    G.add_nodes_from(range(n))
    for i in range(n):
        for j in range(i + 1, n):
            for _ in range(adj[i][j]):
                G.add_edge(i, j)
    
    # Circular layout
    pos = {}
    for i in range(n):
        angle = 2 * math.pi * i / n
        pos[i] = (math.cos(angle), math.sin(angle))
    
    # Draw nodes
    nx.draw_networkx_nodes(G, pos, node_size=500, 
                           node_color=[COLOR_MAP[c] for c in colors], ax=ax)
    
    # Draw edges and label multiplicities
    for u, v, key in G.edges(keys=True):
        if u == v:
            continue
        rad = 0.1 * key - (G.number_of_edges(u, v) - 1) / 2
        edge_pos = {}
        edge_pos[u] = (pos[u][0] + rad * (pos[v][0] - pos[u][0]),
                       pos[u][1] + rad * (pos[v][1] - pos[u][1]))
        edge_pos[v] = (pos[v][0] + rad * (pos[u][0] - pos[v][0]),
                       pos[v][1] + rad * (pos[u][1] - pos[v][1]))
        nx.draw_networkx_edges(G, edge_pos, edgelist=[(u, v)],
                               connectionstyle=f"arc3,rad={rad}", ax=ax)
    
    # Label multiplicities
    for i in range(n):
        for j in range(i + 1, n):
            if adj[i][j] > 1:
                mid_x = (pos[i][0] + pos[j][0]) / 2
                mid_y = (pos[i][1] + pos[j][1]) / 2
                ax.text(mid_x, mid_y, str(adj[i][j]),
                        fontsize=10, ha='center', va='center',
                        bbox=dict(facecolor='white', alpha=0.7, edgecolor='none'))
    
    # Draw vertex labels
    nx.draw_networkx_labels(G, pos, font_size=12, font_weight='bold', ax=ax)
    
    ax.set_title(title, fontsize=10)
    ax.axis('off')

# In main function, when generating results_colored, calculate and store structural counts
def main():
    results = {}
    
    print("Generating all possible graphs...")
    for n in range(2, k+1):
        m = n * (n - 1) // 2
        if m == 0:
            continue
            
        graphs = []
        total_slots = k + m - 1
        
        for star_pos in itertools.combinations(range(total_slots), k):
            counts = [0] * m
            bucket = 0
            star_idx = 0
            for pos in range(total_slots):
                if star_idx < k and pos == star_pos[star_idx]:
                    counts[bucket] += 1
                    star_idx += 1
                elif bucket < m - 1:
                    bucket += 1
            
            adj = [[0] * n for _ in range(n)]
            edge_idx = 0
            for i in range(n):
                for j in range(i + 1, n):
                    adj[i][j] = counts[edge_idx]
                    adj[j][i] = counts[edge_idx]
                    edge_idx += 1
            
            deg = [sum(row) for row in adj]
            odd_deg = sum(1 for d in deg if d % 2 != 0)
            if odd_deg not in (0, 2):
                continue
            
            if not is_connected(adj, n):
                continue
            
            graphs.append(adj)
        
        unique_graphs = {}
        for adj in graphs:
            deg = [sum(row) for row in adj]
            canon_rep = canonical_representation(adj, deg)
            if canon_rep not in unique_graphs:
                unique_graphs[canon_rep] = adj
        results[n] = list(unique_graphs.values())
        print(f"顶点数 {n}: 找到 {len(unique_graphs)} 个唯一图")

    # Generate and deduplicate color-isomorphic graphs (with structural count and factorial product)
    results_colored = {}
    for n, graphs in results.items():
        if not graphs:
            results_colored[n] = []
            continue
            
        color_graphs = []
        for adj in graphs:
            deg = [sum(row) for row in adj]
            for config in generate_color_configurations(adj, deg):
                color_graphs.append(config)
        
        unique_color_graphs = {}
        for adj, colors in color_graphs:
            canon_rep = canonical_representation_with_colors(adj, colors)
            struct_count = count_structural_euler_paths(adj, colors)
            fact_product = compute_factorial_product(adj, colors)  # 新增计算
            if canon_rep not in unique_color_graphs:
                unique_color_graphs[canon_rep] = (adj, colors, struct_count, fact_product)
        
        results_colored[n] = list(unique_color_graphs.values())
        print(f"顶点数 {n}: 找到 {len(unique_color_graphs)} 个颜色同构图")

    # Visualize color-isomorphic graphs (display in pages)
    print("\n可视化结果:")
    for n, graphs in results_colored.items():
        if not graphs:
            continue
            
        total_graphs = len(graphs)
        graphs_per_page = 16 # Maximum 16 graphs per page
        num_pages = (total_graphs + graphs_per_page - 1) // graphs_per_page
        
        for page_idx in range(num_pages):
            start_idx = page_idx * graphs_per_page
            end_idx = min((page_idx + 1) * graphs_per_page, total_graphs)
            page_graphs = graphs[start_idx:end_idx]
            
            num_graphs = len(page_graphs)
            cols = min(4, num_graphs)
            rows = math.ceil(num_graphs / cols)
            
            fig, axes = plt.subplots(rows, cols, figsize=(cols * 3, rows * 3))
            fig.suptitle(f'顶点数: {n} (共 {total_graphs} 个颜色同构图, 第 {page_idx+1}/{num_pages} 页)', fontsize=14)
            
            if num_graphs == 1:
                axes = np.array([[axes]])
            elif rows == 1:
                axes = np.array([axes])
            elif cols == 1:
                axes = axes.reshape(-1, 1)
            
            for idx, (adj, colors, struct_count, fact_product) in enumerate(page_graphs):
                row = idx // cols
                col = idx % cols
                ax = axes[row, col] if rows > 1 or cols > 1 else axes.flatten()[0]
                
                 # Construct title with structural count and factorial product
                title = f"图 {start_idx + idx + 1} (结构数: {struct_count}, 阶乘乘积: {fact_product})"
                draw_graph_with_colors(adj, ax, title, colors)
            
            for idx in range(num_graphs, rows * cols):
                row = idx // cols
                col = idx % cols
                if rows > 1 or cols > 1:
                    axes[row, col].axis('off')
                else:
                    ax.axis('off')
            
            plt.tight_layout()
            plt.subplots_adjust(top=0.9)
            plt.show()

if __name__ == "__main__":
    main()
